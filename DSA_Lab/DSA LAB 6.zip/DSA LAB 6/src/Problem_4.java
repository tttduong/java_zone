class Problem_4
{
    public static void main(String[] args)
    {
        Node a1 = node(2);
        Node b1 = node(3);
        Node c1 = node('+', a1, b1);
        Node d1 = node(5);
        Node e1 = node(1);
        Node f1 = node('-', d1, e1);
        Node g1 = node('*', c1, f1);
        Node h1 = node(8);
        Node i1 = node('/', g1, h1);
        
        Node a2 = node(2);
        Node b2 = node(3);
        Node c2 = node('+', a2, b2);
        Node d2 = node(5);
        Node e2 = node(1);
        Node f2 = node('-', d2, e2);
        Node g2 = node('*', c2, f2);
        Node h2 = node(8);
        Node i2 = node('/', g2, h2);

        System.out.println("Tree 1:");
        showTree(0, i1);
        System.out.println("Tree 2:");
        showTree(0, i2);
        
        // Kiểm tra hai cây có giống nhau không
        System.out.println("Are the trees identical? " + isIdentical(i1, i2));
    }

    // -------------------------------------------------------------
    public static Node node(char op, Node l, Node r)
    {
        Node a = new Node();
        a.operation = op;
        a.leftChild = l;
        a.rightChild = r;
        return a;
    }

    // -------------------------------------------------------------
    public static Node node(int val)
    {
        Node a = new Node();
        a.value = val;
        return a;
    }

    // -------------------------------------------------------------      
    public static void prefix(Node t)
    {
        if (t.leftChild == null && t.rightChild == null) 
            System.out.print(t.value + " ");
        else
        {
            System.out.print(t.operation + " ");
            prefix(t.leftChild);
            prefix(t.rightChild);
        }            
    }

    // -------------------------------------------------------------      
    public static void postfix(Node t)
    {
        if (t.leftChild == null && t.rightChild == null) 
            System.out.print(t.value + " ");
        else
        {
            postfix(t.leftChild);
            postfix(t.rightChild);
            System.out.print(t.operation + " ");
        }            
    }

    // -------------------------------------------------------------      
    public static void infix(Node t)
    {
        if (t.leftChild == null && t.rightChild == null) 
            System.out.print(t.value);
        else
        {
            System.out.print("(");
            infix(t.leftChild);
            System.out.print(t.operation);
            infix(t.rightChild);
            System.out.print(")");
        }            
    }

    // -------------------------------------------------------------      
    public static double eval(Node t)
    {
        double val = 0;
        if (t.leftChild == null && t.rightChild == null) 
            val = t.value;
        else
            switch (t.operation)
            {
                case '+':
                    val = eval(t.leftChild) + eval(t.rightChild);
                    break;
                case '-':
                    val = eval(t.leftChild) - eval(t.rightChild);
                    break;
                case '*':
                    val = eval(t.leftChild) * eval(t.rightChild);
                    break;
                case '/':
                    val = eval(t.leftChild) / eval(t.rightChild);
            }
        return val;
    }

    // -------------------------------------------------------------      
    public static void showTree(int n, Node t)
    {
        tab(n);
        if (t.leftChild == null && t.rightChild == null) 
            System.out.println(t.value);
        else
        {
            System.out.println(t.operation);
            showTree(n + 2, t.leftChild);
            showTree(n + 2, t.rightChild);
        }
    }

    // -------------------------------------------------------------      
    public static void tab(int n)
    {
        for (int i = 0; i < n; i++) System.out.print(" ");
    }

    // -------------------------------------------------------------
    // Phương thức kiểm tra hai cây có giống nhau không
    public static boolean isIdentical(Node root1, Node root2) {
        if (root1 == null && root2 == null) {
            return true;
        }
        if (root1 == null || root2 == null) {
            return false;
        }
        if (root1.operation != root2.operation || root1.value != root2.value) {
            return false;
        }
        return isIdentical(root1.leftChild, root2.leftChild) &&
               isIdentical(root1.rightChild, root2.rightChild);
    }
}
// -------------------------------------------------------------

class Node
{
    char operation;
    int value;
    Node leftChild;
    Node rightChild;
}
